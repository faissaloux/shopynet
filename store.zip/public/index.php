<?php

//phpinfo();
//exit;

require '../app/bootstrap.php';
$app->run();