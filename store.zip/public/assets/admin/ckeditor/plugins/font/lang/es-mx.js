/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'font', 'es-mx', {
	fontSize: {
		label: 'Tamaño',
		voiceLabel: 'Tamaño de letra',
		panelTitle: 'Tamaño de letra'
	},
	label: 'Letra',
	panelTitle: 'Nombre de letra',
	voiceLabel: 'Letra'
} );
